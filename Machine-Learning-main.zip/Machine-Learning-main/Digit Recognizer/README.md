# Digit-Recognizer-using-pixel-data
Code For Digit Recognizer competition on Kaggle. https://www.kaggle.com/c/digit-recognizer

A deep neural network with 2 hidden layers is created using tensorflow. softmax function is used on output layer and RELU is used on all other layers
An accuracy of 0.97914 is obtained

Libraries used:
Tensorflow
Numpy
Pandas
Seaborn
